
public class Kata {

}
