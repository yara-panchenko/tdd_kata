
public class FizzBuzz {

	public int[] getNumers() {
		return new int[100];
	}
}
